# CoinGecko API Status Codes
| Endpoint | HTTP Status Code |
| ---------| ----------------- |
| `/ping` | 200 |
| `/simple/price?ids=bitcoin&vs_currencies=usd` | 200 |
| `/coins/markets?vs_currency=usd&order=market_cap_desc&per_page=1&page=1` | 200 |
